export  class menuviewModel{
    MenuId: number;
    MenuName: string;
    MenuUrl: string;

}