import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HeaderService } from './header.service';
import { menuviewModel } from '../Models/header.Model';
import { isBoolean } from 'util';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  cmpHeading: string;
  isLoggedInuser:boolean = false;
  items: any[] = []; 
  
  
  constructor( private router: Router, private route: ActivatedRoute, private headerService: HeaderService) {
    this.cmpHeading = "My Project App";
    this.items = [
   
      {
        //text: 'MyProfile', path: "myprofile"
      },   
       ];
 
 
   }  
   
  public onSelect({ item }): void {
    if (item) {
      this.router.navigate([item.path]);
    }
  }
  ngOnInit() {
    let currentUser = localStorage.getItem('currentUser');
    this.isLoggedInuser = currentUser != null;  
    
    this.headerService.getmenus(true).subscribe(
      (data) => {
        data.forEach((item) => {
          let submenus: any[] = [];
          if(item.SubMenus != null)
          {
            item.SubMenus.forEach((subItem) => {
              submenus.push({text: subItem.MenuName, path: subItem.MenuUrl});
            });
          }
          this.items.push({text: item.MenuName, path: item.MenuUrl, items: submenus});
        })
      },
      (err) => console.log("Error ", err)
    ) 
    }
  
//  logout(){
//   let currentUser = localStorage.removeItem('currentUser');
//    this.router.navigate(['/login']);
//    }  
  
}
