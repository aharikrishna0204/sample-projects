import { Injectable } from '@angular/core';
import { MenuItem } from '@progress/kendo-angular-menu';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root'})
export class HeaderService {
    visible: boolean;
    restUrl: string = "http://localhost:8081/api/menu";

    constructor(private http: HttpClient) { this.visible = true; }

    hide() { this.visible = false; }

    show() { this.visible = true; }

      getmenus(isAdmin: boolean): any{
        return this.http.get<MenuItem[]>(this.restUrl + '/getmenus/'+isAdmin);
      }
      

}