import { Component, OnInit } from '@angular/core';
import { process, State } from '@progress/kendo-data-query';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../../services/employee.service';
import { employee } from '../../models/Employee.Model';

import {
  GridComponent,
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  Employees: employee[];
  public gridData: GridDataResult;
  public dialogOpened = false;
  public windowOpened = false;
  id: number;
  constructor(private employeeService: EmployeeService, private router: Router) { }

  public state: State = {
    skip: 0,
    take: 10
   };
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.Employees, this.state);
  }
 

  ngOnInit() {

    this.employeeService.getEmployees().subscribe(
      (data) => {
        this.Employees = data
        this.gridData = process(this.Employees, this.state);
      },
      (err) => console.log("Add Error ", err)
    )
  }
  public editHandler({dataItem}) {
    this.router.navigate(['/employee/edit/' + dataItem.ID]);
}
public deleteYes() {
  this.employeeService.delete(this.id).subscribe(
    (data) => {
      this.router.navigate(['/employee/list']);
      this.ngOnInit();
      this.windowOpened = true;
    },
    (err) => console.log("Error ", err)
  )
  this.dialogOpened = false;
}
public deleteNo() {
  this.dialogOpened = false;
}
public close() {
  this.windowOpened = false;
}
public removeHandler({ dataItem }) {
  this.dialogOpened = true;
  this.id = dataItem.ID;
}

addEmployee(): void{
    this.router.navigate(['/employee/add']);
  }

}
