import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DepartmentService } from '../Services/department.service';
import { department } from '../Models/department.Model';
import { Router, ActivatedRoute } from '@angular/router';
import {
  GridComponent,
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-department-add-edit',
  templateUrl: './department-add-edit.component.html',
  styleUrls: ['./department-add-edit.component.css']
})
export class DepartmentAddEditComponent implements OnInit {

  departmentForm: FormGroup;
  submitted = false;
  isEdit = false; 
  public selectedDepartment: any;
  departmentModel: department = {
    Id: 0,
    Name: '',
  };
constructor(private formBuilder: FormBuilder, private departmentService: DepartmentService,
  private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      let id = params['id'];
      if (id > 0) {
        this.isEdit = true;
        this.departmentService.getDepartment(id).subscribe(
          (data) => {
            this.departmentModel = data;
          },
          (err) => console.log("Error ", err)
        )
      }
    });
    this.departmentForm = this.formBuilder.group({
      Name: ['', Validators.required]
    });
  }

// convenience getter for easy access to form fields
get f() { return this.departmentForm.controls; }

onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.departmentForm.invalid) {
    return;
  }
  if (this.departmentModel.Id > 0) {
   this.departmentService.updateDepartment(this.departmentModel).subscribe(
     (data) => {
       //console.log(data)
       this.router.navigate(['/department/list']);
     },
     (err) => console.log("Add Error ", err)
   )
 }else {
  let x = this.selectedDepartment;
  this.departmentService.addDepartment(this.departmentModel).subscribe(
    (data) => {
      //console.log(data)
      this.router.navigate(['/department/list']);
    },
    (err) => console.log("Add Error ", err)
  )
}
}
cancel(): void {
  this.router.navigate(['/department/list']);

}
}