import { Injectable } from '@angular/core';
import { department } from '../models/department.model'; 
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
//import { RequestOptions } from '@angular/http'


@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  restUrl: string = "http://localhost:52824/api/department";
  
  constructor(private http: HttpClient) { }
 
  addDepartment(newDepartment: department): Observable<department> {
    let headers = new HttpHeaders; // ... Set content type to JSON
    let options = { headers: headers };
    return this.http.post<department>(this.restUrl, newDepartment, options);
  }

  getDepartmentes(): any{
    return this.http.get<department[]>(this.restUrl + '/getdepartments');
  }
  getDepartment(id: number): Observable<department> {
    return this.http.get<department>(this.restUrl + '/getdepartment/' + id);
  }

  updateDepartment(newDepartment: department): Observable<department> {
    let headers = new HttpHeaders; // ... Set content type to JSON
    let options = { headers: headers };
    return this.http.post<department>(this.restUrl + "/update", newDepartment, options);
  }
  delete(id: number): Observable<department> {
    return this.http.get<department>(this.restUrl + '/delete/' + id);
  } 
}
