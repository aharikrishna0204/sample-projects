﻿using Models;
using Repository.Interface;
using Services.Inerface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiEntity;

namespace Services.Services
{
    public class EmployeServices : IEmployeeServices
    {
        private static IEmployeeRepository _employeeRepository;

        public EmployeServices(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public void Add(EmployeeModel employeeModel)
        {
            Employee employee = new Employee
            {
                Name = employeeModel.Name,
                Age = employeeModel.Age,
                Gender = employeeModel.Gender,
                Salary = employeeModel.Salary,
                departmentId = employeeModel.departmentId,
                IsActive = true

            };
            Employee SavedEmployee = _employeeRepository.Add(employee);
            _employeeRepository.Save();
        }

        public void Delete(int id)
        {
           Employee employee = _employeeRepository.GetById(id);
            employee.IsActive = false;

            _employeeRepository.Edit(employee);
            _employeeRepository.Save();
        }

        public IEnumerable<EmployeeModel> GetAll()
        {
            return _employeeRepository.GetAll().Where(c => c.IsActive)
                .Select(c => new EmployeeModel()
                {
                    Id = c.Id,
                    Name = c.Name,
                    Age = c.Age,
                    Salary = c.Salary,
                    Gender = c.Gender,
                    departmentId = c.departmentId,
                    DepartmentName = c.Department.Name

                }).ToList();
        }

        public EmployeeModel GetById(int id)
        {
            Employee employee = _employeeRepository.GetById(id);
            return new EmployeeModel()
            {
                Id = employee.Id,
                Name = employee.Name,
                Age = employee.Age,
                Salary = employee.Salary,
                Gender = employee.Gender,
                departmentId = employee.departmentId,
                DepartmentName = employee.Department.Name
            };


        }

        public void Update(EmployeeModel employeeModel)
        {
            Employee employee = _employeeRepository.GetById(employeeModel.Id);
                employee.Name = employeeModel.Name;
                employee.Age = employeeModel.Age;
                employee.Salary = employeeModel.Salary;
                employee.Gender = employeeModel.Gender;
                employee.departmentId = employeeModel.departmentId;

                _employeeRepository.Edit(employee);
                _employeeRepository.Save();
            
        }
    }
}
