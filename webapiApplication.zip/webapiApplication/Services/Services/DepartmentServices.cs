﻿using Models;
using Repository.Interface;
using Repository.Repository;
using Services.Inerface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiEntity;

namespace Services.Services
{
    public class DepartmentServices : IDepartmentServices
    {
        private static IDepartmentRepository _departmentRepository;

        public DepartmentServices(IDepartmentRepository  departmentRepository)
        {
            _departmentRepository = departmentRepository;
        }
        public void Add(DepartmentModel departmentModel)
        {
            Department department = new Department
            {
                Name = departmentModel.Name,
                IsActive = true
            };
            Department savedDepartment = _departmentRepository.Add(department);
            _departmentRepository.Save();
        }

        public void Delete(int id)
        {
            Department department = _departmentRepository.GetById(id);
            department.IsActive = false;

            _departmentRepository.Edit(department);
            _departmentRepository.Save();
        }

        public IEnumerable<DepartmentModel> GetAll()
        {
            return _departmentRepository.GetAll().Where(c => c.IsActive)
                .Select(c => new DepartmentModel()
                {
                    Name = c.Name,
                    Id = c.Id
                }).ToList();
        }

        public DepartmentModel GetById(int id)
        {
            Department department = _departmentRepository.GetById(id);
            return new DepartmentModel()
            {
                Name = department.Name,
                Id = department.Id,
                IsActive = department.IsActive
            };
        }

        public void Update(DepartmentModel departmentModel)
        {
            Department department = _departmentRepository.GetById(departmentModel.Id);
            department.Name = departmentModel.Name;
            department.IsActive = departmentModel.IsActive;

            _departmentRepository.Edit(department);
            _departmentRepository.Save();
        }
    }
}
