﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.Inerface
{
    public interface IEmployeeServices
    { /// <summary>
      /// Services for Add Employee
      /// </summary>
      /// <param name="employeeModel"></param>
        void Add(EmployeeModel employeeModel);

        /// <summary>
        /// Services For Update Employee
        /// </summary>
        /// <param name="employeeModel"></param>
        void Update(EmployeeModel employeeModel);

        /// <summary>
        /// Services For delete Employee
        /// </summary>
        /// <param name="id"></param>
        void Delete(int id);

        /// <summary>
        /// Services for All Employee
        /// </summary>
        /// <returns></returns>
        IEnumerable<EmployeeModel> GetAll();

        /// <summary>
        /// Get Employee By Id 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        EmployeeModel GetById(int id);
    }
}
