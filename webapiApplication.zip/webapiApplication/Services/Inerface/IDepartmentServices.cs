﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiEntity;

namespace Services.Inerface
{
    public interface IDepartmentServices 
    {
        /// <summary>
        /// Services for Add Department
        /// </summary>
        /// <param name="departmentModel"></param>
        void Add(DepartmentModel departmentModel);

        /// <summary>
        /// Services For Update Department
        /// </summary>
        /// <param name="departmentModel"></param>
        void Update(DepartmentModel departmentModel);

        /// <summary>
        /// Services For delete Department
        /// </summary>
        /// <param name="id"></param>
        void Delete(int id);

        /// <summary>
        /// Services for All Department
        /// </summary>
        /// <returns></returns>
        IEnumerable<DepartmentModel> GetAll();

        /// <summary>
        /// Get Department By Id 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        DepartmentModel GetById(int id);
    }
}
