using Repository.Interface;
using Repository.Repository;
using Services.Inerface;
using Services.Services;
using System.Web.Http;
using Unity;
using Unity.WebApi;

namespace webapiApplication
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();
            container.RegisterType<IDepartmentRepository, DepartmentRepository>();
            container.RegisterType<IEmployeeRepository, EmployeeRepository>();

            container.RegisterType<IEmployeeServices, EmployeServices>();
            container.RegisterType<IDepartmentServices, DepartmentServices>();
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}