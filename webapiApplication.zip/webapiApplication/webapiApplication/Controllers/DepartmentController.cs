﻿using Models;
using Services.Inerface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApiEntity;

namespace webapiApplication.Controllers
{
    [RoutePrefix("Api/Department")]
    public class DepartmentController : ApiController
    {
        private static IDepartmentServices _departmentservices;

        public DepartmentController(IDepartmentServices departmentservices)
        {
            _departmentservices = departmentservices;
        }
        // GET: api/Department
        [Route("getDepartments")]
        [HttpGet]
        public IHttpActionResult  Get()
        {
            return Ok(_departmentservices.GetAll());
        }

        // GET: api/Department/5
        [Route("getDepartment/{id}")]
        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            return Ok(_departmentservices.GetById(id));
        }

        // POST: api/Department
        [Route(" ")]
        [HttpPost]
        public IHttpActionResult Post([FromBody]DepartmentModel model)
        {
            _departmentservices.Add(model);
            return Ok();
        }

        // PUT: api/Department/5
        [Route("Update ")]
        [HttpPost]
        public IHttpActionResult UpdateDepartment([FromBody]DepartmentModel model)
        {
            _departmentservices.Update(model);
            return Ok();
        }

        // DELETE: api/Department/5
        [Route("Delete/{id}")]
        [HttpGet]
        public IHttpActionResult Delete(int id)
        {
            _departmentservices.Delete(id);
            return Ok();
        }
    }
}
