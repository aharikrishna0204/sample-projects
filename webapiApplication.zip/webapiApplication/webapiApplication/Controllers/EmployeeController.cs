﻿using Models;
using Services.Inerface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace webapiApplication.Controllers
{
    [RoutePrefix("api/Employee")]
    public class EmployeeController : ApiController
    {
        private static IEmployeeServices _employeeService;

        public EmployeeController(IEmployeeServices employeeServices)
        {
            _employeeService = employeeServices;
        }
        // GET: api/Employee
        [Route("getemployees")]
        [HttpGet]
        public IHttpActionResult Get()
        {
            return Ok(_employeeService.GetAll());
        }

        // GET: api/Employee/5
        [Route("getemployees/{id}")]
        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            return Ok(_employeeService.GetById(id));
        }

        // POST: api/Employee
        [Route("")]
        [HttpPost]
        public IHttpActionResult Post([FromBody]EmployeeModel model)
        {
            _employeeService.Add(model);
            return Ok();
        }

        // PUT: api/Employee/5
        [Route("Update")]
        [HttpPost]
        public IHttpActionResult UpdateEmployee([FromBody]EmployeeModel model)
        {
            _employeeService.Update(model);
            return Ok();
        }

        // DELETE: api/Employee/5
        [Route("Delete/{id}")]
        [HttpGet]
        public IHttpActionResult Delete(int id)
        {
            _employeeService.Delete(id);
            return Ok();
        }
    }
}
