﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IGenericRepository<T> : IDisposable where T : class
    {

        IQueryable<T> GetAll();

        T GetById(int id);

        T Add(T entity);

        void Delete(int id);

        void Edit(T entity);

        void Save();
    }
}
