﻿using Repository.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiEntity;

namespace Repository.Repository
{
    /// <summary>
    /// implementation for Department
    /// </summary>
    public class DepartmentRepository : GenericRepository<WebApiEntityData, Department>, IDepartmentRepository
    {
    }
}
