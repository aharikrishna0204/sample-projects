import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DepartmentListComponent } from './department-list/department-list.component';
import { GridModule } from '@progress/kendo-angular-grid';
import { DepartmentService } from './Services/department.service';
import { HeaderComponent } from './header/header.component';
import { MenuModule } from '@progress/kendo-angular-menu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderService } from './header/header.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { DialogsModule, WindowModule } from '@progress/kendo-angular-dialog';
import { DepartmentAddEditComponent } from './department-add-edit/department-add-edit.component';
import { EmployeeListComponent } from './Employee/employee-list/employee-list.component';
import { EmployeeAddEditComponent } from './employee-add-edit/employee-add-edit.component';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DepartmentListComponent,
    DepartmentAddEditComponent,
    DepartmentAddEditComponent,
    EmployeeListComponent,
    EmployeeAddEditComponent
  ],
  imports: [
    BrowserModule, FormsModule, ReactiveFormsModule, GridModule, HttpClientModule,DropDownsModule,
    RouterModule.forRoot([
      { path: "department/list", component: DepartmentListComponent },
      { path: "department/add", component: DepartmentAddEditComponent },
      { path: "department/edit/:id", component: DepartmentAddEditComponent },
      { path: "department/delete", component: DepartmentAddEditComponent },
      { path: "employee/list", component: EmployeeListComponent },
      { path: "employee/add", component: EmployeeAddEditComponent },
      { path: "employee/edit/:id", component: EmployeeAddEditComponent },
      { path: "employee/delete", component: EmployeeAddEditComponent },
    ]),
    GridModule,
    AppRoutingModule,
    MenuModule,
    BrowserAnimationsModule,
    DialogsModule
  ],
  providers: [DepartmentService, HeaderService, HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
