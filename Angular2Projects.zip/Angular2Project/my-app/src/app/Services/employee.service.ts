import { Injectable } from '@angular/core';
import { employee } from '../models/employee.model'; 
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  restUrl: string = "http://localhost:52824/api/employee";
  
  constructor(private http: HttpClient) { }
 
  addEmployee(newEmployee: employee): Observable<employee> {
    let headers = new HttpHeaders; // ... Set content type to JSON
    let options = { headers: headers };
    return this.http.post<employee>(this.restUrl, newEmployee, options);
  }

  getEmployees(): any{
    return this.http.get<employee[]>(this.restUrl + '/getemployee');
  }
  getEmployee(id: number): Observable<employee> {
    return this.http.get<employee>(this.restUrl + '/getemployee/' + id);
  }

  updateEmployee(newEmployee: employee): Observable<employee> {
    let headers = new HttpHeaders; // ... Set content type to JSON
    let options = { headers: headers };
    return this.http.post<employee>(this.restUrl + "/update", newEmployee, options);
  }
  delete(id: number): Observable<employee> {
    return this.http.get<employee>(this.restUrl + '/delete/' + id);
  } 
}

