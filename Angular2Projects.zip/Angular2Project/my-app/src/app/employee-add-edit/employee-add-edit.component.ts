import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { employee } from '../models/Employee.Model';
import { Router,ActivatedRoute } from '@angular/router';
import { DepartmentService } from '../Services/department.service';

@Component({
  selector: 'app-employee-add-edit',
  templateUrl: './employee-add-edit.component.html',
  styleUrls: ['./employee-add-edit.component.css']
})
export class EmployeeAddEditComponent implements OnInit {

  EmployeeForm: FormGroup;
  submitted = false;
  isEdit = false; 
  public selectedEmployee: any;
  employeeModel: employee = {
    Id: 0,
    Name: '',
    Organisation:'',
    Salary:null,
    Address:'',
    Password:'',
    DepartmentId: null,    
    DepartmentName:``
  };
  public DepartmentDropList: any = [];
  constructor(private formBuilder: FormBuilder, private employeeService : EmployeeService, private DepartmentService: DepartmentService,
    private router: Router,private route: ActivatedRoute) { }
    public defaultItemDepertment: { Name: string, Id: number } = { Name: "Select ", Id: null };

  ngOnInit()  {
    this.route.params.subscribe(params => {
      let id = params['id'];
      if (id > 0) {
        this.isEdit = true;
        this.employeeService.getEmployee(id).subscribe(
          (data) => {
            this.employeeModel = data;  
            this.selectedEmployee = <any> {DepartmentName :data.DepartmentName,ID:data.DepartmentId} 
          },
          (err) => console.log("Error ", err)
        )
      }
    });
    this.EmployeeForm = this.formBuilder.group({
     // BoxNo: [ null, Validators.required],
      DepartmentID:[this.selectedEmployee,[]]
    }); 
    this.DepartmentService.getDepartmentes().subscribe(
      (data) => {
        this.DepartmentDropList = data;
      },
      (err) => console.log("Add Error ", err)
    )
  } 
  // convenience getter for easy access to form fields
  get f() { return this.EmployeeForm.controls; }   
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.EmployeeForm.invalid) {
      return;
    }
    if (this.employeeModel.Id > 0) {
      this.employeeService.updateEmployee(this.employeeModel).subscribe(
        (data) => {
          //console.log(data)
          this.router.navigate(['/employee/list']);
        },
        (err) => console.log("Add Error ", err)
      )
    } else {
    
     let x=this.selectedEmployee;
    this.employeeService.addEmployee(this.employeeModel).subscribe(
      (data) => {
        //console.log(data)
        this.router.navigate(['/employee/list']);
      },
      (err) => console.log("Add Error ", err)
    )
  }
  }
  DepartmentChange(value): void {
    this.employeeModel.DepartmentId = value.ID;
  }
  cancel(): void {
    this.router.navigate(['/employee/list']);
  }  
}
