import { Component, OnInit } from '@angular/core';
import { process, State } from '@progress/kendo-data-query';
import { DepartmentService } from '../Services/department.service';
import { Router, ActivatedRoute } from '@angular/router';
import { department } from '../Models/department.Model';
import {
  GridComponent,
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';


@Component({
  selector: 'app-department-list',
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.css']
})
export class DepartmentListComponent implements OnInit {

  department: department[];
  public gridData: GridDataResult;
  public dialogOpened = false;
  public windowOpened = false;
  id: number;
  constructor(private departmentService: DepartmentService, private router: Router) { }
  public state: State = {
    skip: 0,
    take: 10,
  };
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.department, this.state);
  }

  ngOnInit() {

    this.departmentService.getDepartmentes().subscribe(
      (data) => {
        this.department = data
        this.gridData = process(this.department, this.state);
      },
      (err) => console.log("Add Error ", err)
    )
  }
  public editHandler({ dataItem }) {
    this.router.navigate(['/department/edit/' + dataItem.Id]);
  }
  public deleteYes() {
    this.departmentService.delete(this.id).subscribe(
      (data) => {
        this.router.navigate(['/department/list']);
        this.ngOnInit();
        this.windowOpened = true;
      },
      (err) => console.log("Error ", err)
    )
    this.dialogOpened = false;
  }
  public deleteNo() {
    this.dialogOpened = false;
  }
  public close() {
    this.windowOpened = false;
  }

  public removeHandler({ dataItem }) {
    this.dialogOpened = true;
    this.id = dataItem.Id;
  }
  addDepartment(): void {
    this.router.navigate(['/department/add']);
  }
}