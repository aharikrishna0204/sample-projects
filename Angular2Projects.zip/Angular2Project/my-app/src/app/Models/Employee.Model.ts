export class employee {
    Id: number;
    Name: string;
    Salary: string;
    Organisation: string;
    Address: string;
    Password:string;
    DepartmentId: number;
    DepartmentName: string;   
}