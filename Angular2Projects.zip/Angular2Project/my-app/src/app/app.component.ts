import { Component, OnInit } from '@angular/core';
import { Router } from '../../node_modules/@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit  {
ngOnInit(): void {
  console.log('app oninit..');
}
title = 'app';
appHeading: string;
count:number = 0;
constructor(private router: Router, private location: Location) {
  // var title = this.location.prepareExternalUrl(this.location.path());
  // console.log(title);
  // title = title.slice(1);
  // console.log(title);
  this.appHeading = "My App Heading";
}
}

