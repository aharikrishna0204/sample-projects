﻿using Models;
using NetworkBL;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Network.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            EmployeeBL employBl = new EmployeeBL(new EmployeeRepository());
            var employees = employBl.GetAll();
            return View(employees);
            
        }

        // GET: Employee/Details/5
        public ActionResult Details(int id)
        {
            return View(id);
        }

        // GET: Employee/Create
        public ActionResult Create()
     {
            EmployeeBL employBl = new EmployeeBL(new EmployeeRepository());
            var department = employBl.GetDepartments();
            EmployeeModel employeeModel = new EmployeeModel();
            employeeModel.Departments = department.Select(a => new SelectListItem() { Value = a.Id.ToString(), Text = a.Name }).ToList();
            return View(employeeModel);
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Create(EmployeeModel employ)
        {
            try
            {
                // TODO: Add insert logic here

                EmployeeBL employBl = new EmployeeBL(new EmployeeRepository());
                employBl.Add(employ);


                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            EmployeeBL employBl = new EmployeeBL(new EmployeeRepository());
            var department = employBl.GetDepartments();
            EmployeeModel employeeModel = employBl.GetById(id);
            employeeModel.Departments = department.Select(a => new SelectListItem() { Value = a.Id.ToString(), Text = a.Name }).ToList();
            return View(employeeModel);
            
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, EmployeeModel employ)
        {
            try
            {
                EmployeeBL employBl = new EmployeeBL(new EmployeeRepository());
                employBl.Update(employ);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            EmployeeBL employBl = new EmployeeBL(new EmployeeRepository());
            var employ = employBl.GetById(id);
            return View(employ);
        }

        // POST: Employee/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, EmployeeModel employ)
        {
            try
            {
                // TODO: Add delete logic here
                EmployeeBL employBl = new EmployeeBL(new EmployeeRepository());
                employBl.Delete(id);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
