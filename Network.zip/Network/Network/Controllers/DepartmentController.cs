﻿using Models;
using NetworkBL;
using Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Network.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department
        public ActionResult Index()
        {
            DepartmentBL departmentBl = new DepartmentBL(new DepartmentRepository());
            var department = departmentBl.GetAll();
            return View(department);
        }

        // GET: Department/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Department/Create
        public ActionResult Create()
        {
            return View(new DepartmentModel());
        }

        // POST: Department/Create
        [HttpPost]
        public ActionResult Create(DepartmentModel department)
        {
            try
            {
                // TODO: Add insert logic here
                DepartmentBL departmentBl = new DepartmentBL(new DepartmentRepository());
                departmentBl.Add(department);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Department/Edit/5
        public ActionResult Edit(int id)
        {
            DepartmentBL departmentBl = new DepartmentBL(new DepartmentRepository());
            var department = departmentBl.GetById(id);
            return View(department);
        }

        // POST: Department/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, DepartmentModel department)
        {
            try
            {
                // TODO: Add update logic here
                DepartmentBL departmentBl = new DepartmentBL(new DepartmentRepository());
                departmentBl.Update(new DepartmentModel() { Id = department.Id, Name = department.Name, IsActive = department.IsActive });
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Department/Delete/5
        public ActionResult Delete(int id)
        {
            DepartmentBL departmentBl = new DepartmentBL(new DepartmentRepository());
            var department = departmentBl.GetById(id);
            return View(department);
        }

        // POST: Department/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                DepartmentBL departmentBl = new DepartmentBL(new DepartmentRepository());
                departmentBl.Delete(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
