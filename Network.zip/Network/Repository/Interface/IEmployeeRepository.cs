﻿using Models;
using NetworkData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Interface
{
    public interface IEmployeeRepository
    {
       void Add(Employee employee);
        void Update(Employee employee);
        void Delete(int id);
        List<Employee> GetAll();
        Employee GetById(int id);
        List<Department> GetDepartments();
    }
}
