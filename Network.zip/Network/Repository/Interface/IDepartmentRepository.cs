﻿using NetworkData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Interface
{
    public interface IDepartmentRepository
    {
        void Add(Department department);
        Department GetById(int id);
        List<Department> GetAll();
        void Update(Department department);
        void Delete(int id);
    }
}
