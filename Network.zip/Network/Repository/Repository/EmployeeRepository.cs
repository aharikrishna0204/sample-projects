﻿using Models;
using NetworkData;
using Repository.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repository
{
    public  class EmployeeRepository: IEmployeeRepository
    {
        public readonly NetworkCableEntity _context = new NetworkCableEntity();

        public void Add(Employee employee)
        {
            _context.Employees.Add(employee);
            _context.SaveChanges();

        }

        public void Delete(int id)
        {
            Employee _employee = _context.Employees.Find(id);
            _context.Employees.Remove(_employee);
            _context.SaveChanges();
        }

        public List<Employee> GetAll()
        {
            return _context.Employees.ToList();
        }

        public Employee GetById(int id)
        {
            return _context.Employees.Find(id);
        }

        public void Update(Employee employee)
        {
            Employee _employee = _context.Employees.Find(employee.Id);
            _employee.Name = employee.Name;
            _employee.Salary = employee.Salary;
            _employee.Gender = employee.Gender;
            _employee.Age = employee.Age;
            _employee.departmentId = employee.departmentId;
            _employee.IsActive = employee.IsActive;
            _context.Entry(_employee).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public List<Department> GetDepartments()
        {
            return _context.Departments.ToList();
        }
    }
}
