﻿using NetworkData;
using Repository.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repository
{
    public class DepartmentRepository : IDepartmentRepository
    {

        public readonly NetworkCableEntity _context = new NetworkCableEntity();

        public void Add(Department department)
        {
            _context.Departments.Add(department);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
           Department _department = _context.Departments.Find(id);
            _context.Departments.Remove(_department);
            _context.SaveChanges();
        }

        public List<Department> GetAll()
        {
            return _context.Departments.ToList();
        }

        public Department GetById(int id)
        {
            return _context.Departments.Find(id);
        }

        public void Update(Department department)
        {
            Department _department = _context.Departments.Find(department.Id);
            _department.Name = department.Name;
            _department.IsActive = department.IsActive;
            _context.Entry(_department).State = EntityState.Modified;
            _context.SaveChanges();
        }
    }
}
