﻿using Models;
using NetworkData;
using Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkBL
{
    public class DepartmentBL
    {
        public readonly IDepartmentRepository _departmentRepo;

        public DepartmentBL(IDepartmentRepository departmentRepo)
        {
            _departmentRepo = departmentRepo;
        }
        public void Add(DepartmentModel department)
        {
            Department _department = new Department();
            _department.Name = department.Name;
            _department.IsActive = department.IsActive;
            _departmentRepo.Add(_department);
        }

        public void Update(DepartmentModel department)
        {
            Department _department = new Department();
            _department.Name = department.Name;
            _department.IsActive = department.IsActive;
            _department.Id = department.Id;
            _departmentRepo.Update(_department);
        }

        public DepartmentModel GetById(int id)
        {
            Department department = _departmentRepo.GetById(id);
            return new DepartmentModel()
            {
                Id = department.Id,
                Name = department.Name,
                IsActive = department.IsActive
            };
        }
        public void Delete(int id)
        {
            Department _department = new Department(); ;
            _department.Id = id;
            _departmentRepo.Delete(id);

        }


        public List<DepartmentModel> GetAll()
        {
            List<Department> departments = _departmentRepo.GetAll();
            List<DepartmentModel> departmentList = new List<DepartmentModel>();

            foreach (Department department in departments)
            {
                DepartmentModel model = new DepartmentModel();
                model.Id = department.Id;
                model.Name = department.Name;
                model.IsActive = department.IsActive;
                departmentList.Add(model);
            }
            return departmentList;
        }
    }
}