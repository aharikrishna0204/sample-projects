﻿using Models;
using NetworkData;
using Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkBL
{
    public class EmployeeBL
    {
        public readonly IEmployeeRepository _employeeRepo;

        public EmployeeBL(IEmployeeRepository employeeRepo)
        {
            _employeeRepo = employeeRepo;
        }
        public void Add(EmployeeModel employee)
        {
            Employee _employee = new Employee();
            _employee.Name = employee.Name;
            _employee.Age = employee.Age;
            _employee.Salary = employee.Salary;
            _employee.Gender = employee.Gender;
            _employee.IsActive = employee.IsActive;
            _employee.departmentId = employee.departmentId;
            _employeeRepo.Add(_employee);
        }

        public void Update(EmployeeModel employee)
        {
            Employee _employee = new Employee();
            _employee.Name = employee.Name;
            _employee.Age = employee.Age;
            _employee.Salary = employee.Salary;
            _employee.Gender = employee.Gender;
            _employee.IsActive = employee.IsActive;
            _employee.Id = employee.Id;
            _employee.departmentId = employee.departmentId;
            _employeeRepo.Update(_employee);
        }

        public EmployeeModel GetById(int id)
        {
            Employee employee = _employeeRepo.GetById(id);
            return new EmployeeModel()
            {
                Id = employee.Id,
                Name = employee.Name,
                Salary = employee.Salary,
                Age = employee.Age,
                Gender = employee.Gender,
                departmentId = employee.departmentId,
                IsActive = employee.IsActive
            };
        }
        public void Delete(int id)
        {
            Employee _employee = new Employee();
            _employee.Id = id;
            _employeeRepo.Delete(id);

        }


        public List<EmployeeModel> GetAll()
        {
            List<Employee> employees = _employeeRepo.GetAll();
            List<EmployeeModel> employeeList = new List<EmployeeModel>();

            foreach (Employee employee in employees)
            {
                EmployeeModel model = new EmployeeModel();
                model.Id = employee.Id;
                model.Name = employee.Name;
                model.Age = employee.Age;
                model.Gender = employee.Gender;
                model.Salary = employee.Salary;
                model.Department = new DepartmentModel();
                model.Department.Name = employee.Department.Name;
                model.IsActive = employee.IsActive;
                employeeList.Add(model);
            }
            return employeeList;
        }

        public List<DepartmentModel> GetDepartments()
        {
            var department = _employeeRepo.GetDepartments()
               .Select(a => new DepartmentModel()
               {
                   Id = a.Id,
                   Name = a.Name,
                   

               }).ToList();

            return department;
        }
    }
}