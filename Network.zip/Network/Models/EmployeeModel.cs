﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Models
{
    public class EmployeeModel
    {
        public int Id { get; set; }

        
        public string Name { get; set; }

      
        public decimal? Salary { get; set; }

      
        public string Gender { get; set; }

        public string Age { get; set; }

        public bool? IsActive { get; set; }

        public int departmentId { get; set; }
        public DepartmentModel Department { get; set; }
        public IEnumerable<SelectListItem> Departments { get; set; }
        
    }
}
